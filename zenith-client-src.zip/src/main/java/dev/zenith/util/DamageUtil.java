package dev.zenith.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Estimates explosion damage (crystal power 6, respawn anchor power 5). Enchantments are ignored. */
public final class DamageUtil {
    private DamageUtil() {}

    public static float explosion(Vec3d center, Entity e, float power) {
        double q = power * 2.0;
        double dist = Math.sqrt(e.squaredDistanceTo(center)) / q;
        if (dist > 1.0) return 0f;
        double impact = (1.0 - dist) * exposure(center, e);
        float dmg = (float) ((impact * impact + impact) / 2.0 * 7.0 * q + 1.0);
        if (e instanceof LivingEntity le) {
            dmg *= 1f - Math.min(20, le.getArmor()) / 25f;
        }
        return Math.max(0f, dmg);
    }

    private static double exposure(Vec3d center, Entity e) {
        var world = MinecraftClient.getInstance().world;
        if (world == null) return 1.0;
        Box b = e.getBoundingBox();
        Vec3d c = b.getCenter();
        Vec3d[] points = {
                new Vec3d(c.x, b.minY + 0.1, c.z),
                c,
                new Vec3d(c.x, b.maxY - 0.1, c.z)
        };
        int clear = 0;
        for (Vec3d pt : points) {
            var hit = world.raycast(new RaycastContext(center, pt,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, e));
            if (hit.getType() == HitResult.Type.MISS) clear++;
        }
        return clear / (double) points.length;
    }
}
