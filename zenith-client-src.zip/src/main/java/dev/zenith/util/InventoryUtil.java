package dev.zenith.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.function.Predicate;

public final class InventoryUtil {
    private InventoryUtil() {}

    public static int findHotbar(Predicate<ItemStack> test) {
        var p = MinecraftClient.getInstance().player;
        if (p == null) return -1;
        for (int i = 0; i < 9; i++) if (test.test(p.getInventory().getStack(i))) return i;
        return -1;
    }

    public static int findHotbar(Item item) {
        return findHotbar(s -> s.isOf(item));
    }

    public static void select(int slot) {
        var p = MinecraftClient.getInstance().player;
        if (p != null && slot >= 0 && slot < 9 && p.getInventory().getSelectedSlot() != slot) {
            p.getInventory().setSelectedSlot(slot);
        }
    }
}
