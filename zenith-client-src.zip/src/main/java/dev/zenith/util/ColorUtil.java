package dev.zenith.util;

import dev.zenith.ZenithClient;
import dev.zenith.module.impl.HudModule;

import java.awt.Color;

public final class ColorUtil {
    private ColorUtil() {}

    public static final int BG = 0xE0101216;
    public static final int PANEL_HEADER = 0xF0171A21;
    public static final int ROW = 0xB0161920;
    public static final int ROW_HOVER = 0xC0222731;
    public static final int TEXT = 0xFFE6E9EF;
    public static final int TEXT_DIM = 0xFF8A93A3;

    /** ARGB with full alpha from an RGB int. */
    public static int opaque(int rgb) {
        return 0xFF000000 | rgb;
    }

    public static int rainbow(long offsetMs, float saturation) {
        float hue = ((System.currentTimeMillis() + offsetMs) % 6000L) / 6000f;
        return opaque(Color.HSBtoRGB(hue, saturation, 1f));
    }

    /** The current theme accent; {@code offset} lets rainbow-style themes shift per row. */
    public static int accent(int offset) {
        HudModule hud = ZenithClient.modules().get(HudModule.class);
        String theme = hud == null ? "Storm" : hud.theme.get();
        return switch (theme) {
            case "Storm" -> ZeusTheme.accent(offset);
            case "Cyan" -> 0xFF35D6E8;
            case "Purple" -> 0xFFA66BFF;
            case "Crimson" -> 0xFFE8344F;
            case "Emerald" -> 0xFF2FD27E;
            default -> rainbow(offset * 90L, 0.6f);
        };
    }

    public static int withAlpha(int argb, int alpha) {
        return (alpha << 24) | (argb & 0xFFFFFF);
    }
}
