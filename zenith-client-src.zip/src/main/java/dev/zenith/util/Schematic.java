package dev.zenith.util;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Block list read from a .litematic, .schem (Sponge v2/v3) or vanilla structure .nbt file. Block states are reduced to block names. */
public final class Schematic {
    public int width, height, length;
    public final List<String> palette = new ArrayList<>();
    private final List<int[]> blocks = new ArrayList<>(); // x, y, z, paletteIndex

    public int size() { return blocks.size(); }
    public int x(int i) { return blocks.get(i)[0]; }
    public int y(int i) { return blocks.get(i)[1]; }
    public int z(int i) { return blocks.get(i)[2]; }
    public String name(int i) { return palette.get(blocks.get(i)[3]); }

    private int paletteIndex(String name) {
        int i = palette.indexOf(name);
        if (i >= 0) return i;
        palette.add(name);
        return palette.size() - 1;
    }

    private static boolean air(String n) {
        return n.endsWith(":air") || n.endsWith("cave_air") || n.endsWith("void_air") || n.endsWith("structure_void");
    }

    private void add(int x, int y, int z, String name) {
        if (name == null || air(name)) return;
        blocks.add(new int[]{x, y, z, paletteIndex(name)});
    }

    public static Schematic load(Path file) throws IOException {
        Map<String, Object> root = Nbt.map(Nbt.read(file));
        String lower = file.getFileName().toString().toLowerCase(Locale.ROOT);
        Schematic s = new Schematic();
        if (lower.endsWith(".litematic")) s.readLitematic(root);
        else if (lower.endsWith(".schem")) s.readSponge(root);
        else s.readStructure(root);
        if (s.size() == 0) throw new IOException("No blocks found in file");
        return s;
    }

    private void readLitematic(Map<String, Object> root) {
        Map<String, Object> regions = Nbt.map(root.get("Regions"));
        List<int[]> origins = new ArrayList<>();
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        List<Map<String, Object>> list = new ArrayList<>();
        for (Object r : regions.values()) {
            Map<String, Object> reg = Nbt.map(r);
            Map<String, Object> pos = Nbt.map(reg.get("Position")), size = Nbt.map(reg.get("Size"));
            int sx = Nbt.num(size.get("x")), sy = Nbt.num(size.get("y")), sz = Nbt.num(size.get("z"));
            int bx = Nbt.num(pos.get("x")) + (sx < 0 ? sx + 1 : 0);
            int by = Nbt.num(pos.get("y")) + (sy < 0 ? sy + 1 : 0);
            int bz = Nbt.num(pos.get("z")) + (sz < 0 ? sz + 1 : 0);
            origins.add(new int[]{bx, by, bz, Math.abs(sx), Math.abs(sy), Math.abs(sz)});
            list.add(reg);
            minX = Math.min(minX, bx); minY = Math.min(minY, by); minZ = Math.min(minZ, bz);
            maxX = Math.max(maxX, bx + Math.abs(sx)); maxY = Math.max(maxY, by + Math.abs(sy)); maxZ = Math.max(maxZ, bz + Math.abs(sz));
        }
        width = maxX - minX; height = maxY - minY; length = maxZ - minZ;
        for (int r = 0; r < list.size(); r++) {
            Map<String, Object> reg = list.get(r);
            int[] o = origins.get(r);
            List<Object> pal = Nbt.list(reg.get("BlockStatePalette"));
            String[] names = new String[pal.size()];
            for (int i = 0; i < names.length; i++) names[i] = (String) Nbt.map(pal.get(i)).get("Name");
            Object states = reg.get("BlockStates");
            if (!(states instanceof long[] data) || names.length == 0) continue;
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(names.length - 1));
            long mask = (1L << bits) - 1;
            int w = o[3], h = o[4], l = o[5];
            for (int y = 0; y < h; y++) for (int z = 0; z < l; z++) for (int x = 0; x < w; x++) {
                long bit = ((long) y * l * w + (long) z * w + x) * bits;
                int start = (int) (bit >> 6), off = (int) (bit & 63);
                if (start >= data.length) continue;
                long v = data[start] >>> off;
                if (off + bits > 64 && start + 1 < data.length) v |= data[start + 1] << (64 - off);
                int idx = (int) (v & mask);
                if (idx < names.length) add(o[0] - minX + x, o[1] - minY + y, o[2] - minZ + z, names[idx]);
            }
        }
    }

    private void readSponge(Map<String, Object> root) {
        Map<String, Object> body = root;
        Map<String, Object> blocksTag = null;
        if (root.containsKey("Schematic")) body = Nbt.map(root.get("Schematic"));
        width = Nbt.num(body.get("Width")); height = Nbt.num(body.get("Height")); length = Nbt.num(body.get("Length"));
        Map<String, Object> pal;
        byte[] data;
        if (body.containsKey("Blocks")) {
            blocksTag = Nbt.map(body.get("Blocks"));
            pal = Nbt.map(blocksTag.get("Palette"));
            data = blocksTag.get("Data") instanceof byte[] b ? b : new byte[0];
        } else {
            pal = Nbt.map(body.get("Palette"));
            data = body.get("BlockData") instanceof byte[] b ? b : new byte[0];
        }
        String[] byId = new String[pal.size() + 1];
        for (Map.Entry<String, Object> e : pal.entrySet()) {
            int id = Nbt.num(e.getValue());
            String n = e.getKey();
            int br = n.indexOf('[');
            if (id >= 0 && id < byId.length) byId[id] = br >= 0 ? n.substring(0, br) : n;
        }
        int pos = 0, index = 0;
        while (pos < data.length) {
            int value = 0, shift = 0;
            while (true) {
                int b = data[pos++] & 0xFF;
                value |= (b & 0x7F) << shift;
                if ((b & 0x80) == 0 || pos >= data.length) break;
                shift += 7;
            }
            int x = index % Math.max(1, width);
            int z = (index / Math.max(1, width)) % Math.max(1, length);
            int y = index / Math.max(1, width * length);
            if (value >= 0 && value < byId.length) add(x, y, z, byId[value]);
            index++;
        }
    }

    private void readStructure(Map<String, Object> root) {
        List<Object> size = Nbt.list(root.get("size"));
        if (size.size() == 3) { width = Nbt.num(size.get(0)); height = Nbt.num(size.get(1)); length = Nbt.num(size.get(2)); }
        List<Object> pal = Nbt.list(root.get("palette"));
        String[] names = new String[pal.size()];
        for (int i = 0; i < names.length; i++) names[i] = (String) Nbt.map(pal.get(i)).get("Name");
        for (Object o : Nbt.list(root.get("blocks"))) {
            Map<String, Object> b = Nbt.map(o);
            List<Object> p = Nbt.list(b.get("pos"));
            int state = Nbt.num(b.get("state"));
            if (p.size() == 3 && state >= 0 && state < names.length) add(Nbt.num(p.get(0)), Nbt.num(p.get(1)), Nbt.num(p.get(2)), names[state]);
        }
    }
}
