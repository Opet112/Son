package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.block.BlockState;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class AutoTool extends Module {
    private final Setting.Bool restore = add(new Setting.Bool("Switch back", true));
    private int previous = -1;

    public AutoTool() {
        super("AutoTool", "Picks the fastest hotbar tool while you mine.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        boolean mining = mc.options.attackKey.isPressed()
                && mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK;
        if (!mining) {
            if (previous >= 0 && restore.get()) p.getInventory().setSelectedSlot(previous);
            previous = -1;
            return;
        }
        BlockState state = mc.world.getBlockState(((BlockHitResult) mc.crosshairTarget).getBlockPos());
        int current = p.getInventory().getSelectedSlot();
        int best = current;
        float bestSpeed = p.getInventory().getStack(current).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            float sp = p.getInventory().getStack(i).getMiningSpeedMultiplier(state);
            if (sp > bestSpeed) { bestSpeed = sp; best = i; }
        }
        if (best != current) {
            if (previous < 0) previous = current;
            p.getInventory().setSelectedSlot(best);
        }
    }
}
