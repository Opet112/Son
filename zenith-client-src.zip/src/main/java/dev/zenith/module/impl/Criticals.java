package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class Criticals extends Module {
    public Criticals() {
        super("Criticals", "Turns attacks from KillAura/TriggerBot/AutoClicker into critical hits using packets.", Category.COMBAT);
    }

    /** Call right before sending an attack. */
    public static void apply() {
        Criticals c = ZenithClient.modules().get(Criticals.class);
        if (c == null || !c.isEnabled()) return;
        var p = mc.player;
        var handler = mc.getNetworkHandler();
        if (p == null || handler == null || !p.isOnGround() || p.isTouchingWater() || p.isInLava() || p.isClimbing()) return;
        double x = p.getX(), y = p.getY(), z = p.getZ();
        handler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false, p.horizontalCollision));
        handler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, p.horizontalCollision));
    }
}
