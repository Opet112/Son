package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.List;

/** Marks 1x1 holes whose floor and four walls are bedrock/obsidian (safe spots for crystal PvP). */
public class HoleEsp extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 8, 3, 16, 1));
    private volatile List<BlockPos> bedrock = new ArrayList<>();
    private volatile List<BlockPos> obsidian = new ArrayList<>();
    private int timer;

    public HoleEsp() {
        super("HoleEsp", "Highlights safe obsidian/bedrock holes.", Category.RENDER);
    }

    private static boolean solid(Block b) { return b == Blocks.BEDROCK || b == Blocks.OBSIDIAN; }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null || timer++ % 5 != 0) return;
        int r = range.getInt();
        int px = (int) Math.floor(mc.player.getX()), py = (int) Math.floor(mc.player.getY()), pz = (int) Math.floor(mc.player.getZ());
        List<BlockPos> bed = new ArrayList<>(), obi = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            int bx = px + x, by = py + y, bz = pz + z;
            if (!mc.world.getBlockState(m.set(bx, by, bz)).isAir() || !mc.world.getBlockState(m.set(bx, by + 1, bz)).isAir()) continue;
            Block floor = mc.world.getBlockState(m.set(bx, by - 1, bz)).getBlock();
            Block n = mc.world.getBlockState(m.set(bx, by, bz - 1)).getBlock();
            Block s = mc.world.getBlockState(m.set(bx, by, bz + 1)).getBlock();
            Block e = mc.world.getBlockState(m.set(bx + 1, by, bz)).getBlock();
            Block w = mc.world.getBlockState(m.set(bx - 1, by, bz)).getBlock();
            if (!solid(floor) || !solid(n) || !solid(s) || !solid(e) || !solid(w)) continue;
            boolean allBedrock = floor == Blocks.BEDROCK && n == Blocks.BEDROCK && s == Blocks.BEDROCK && e == Blocks.BEDROCK && w == Blocks.BEDROCK;
            (allBedrock ? bed : obi).add(new BlockPos(bx, by, bz));
        }
        bedrock = bed;
        obsidian = obi;
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        draw(ctx, pr, bedrock, 0xFF2FD27E);
        draw(ctx, pr, obsidian, 0xFFE8344F);
    }

    private static void draw(DrawContext ctx, Projector pr, List<BlockPos> list, int color) {
        for (BlockPos p : list) {
            double[] s = pr.box(new Box(p));
            if (s != null) DrawUtil.outline(ctx, (int) s[0], (int) s[1], (int) s[2], (int) s[3], color);
        }
    }
}
