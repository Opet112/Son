package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class NameTags extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 96, 8, 200, 8));
    private final Setting.Bool distance = add(new Setting.Bool("Distance", true));

    public NameTags() {
        super("NameTags", "Name, health and distance above players (visible through walls).", Category.RENDER);
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        float partial = ZenithClient.partial();
        Projector pr = Projector.create(partial);
        if (pr == null) return;
        var tr = mc.textRenderer;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player || mc.player.distanceTo(e) > range.get()) continue;
            Vec3d head = e.getLerpedPos(partial).add(0, e.getHeight() + 0.4, 0);
            double[] s = pr.project(head);
            if (s == null) continue;
            String text = e.getName().getString() + " " + String.format("%.0f", e.getHealth() + e.getAbsorptionAmount())
                    + (distance.get() ? " " + (int) mc.player.distanceTo(e) + "m" : "");
            int w = tr.getWidth(text);
            int x = (int) s[0] - w / 2, y = (int) s[1] - 10;
            ctx.fill(x - 2, y - 1, x + w + 2, y + 9, 0x90101216);
            ctx.drawText(tr, text, x, y, EntityUtil.isFriend(e) ? 0xFF35D6E8 : ColorUtil.TEXT, true);
        }
    }
}
