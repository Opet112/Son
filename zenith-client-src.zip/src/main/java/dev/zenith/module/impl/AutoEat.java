package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class AutoEat extends Module {
    private final Setting.Num hunger = add(new Setting.Num("Eat below", 14, 1, 19, 1));
    private boolean eating;
    private int previousSlot = -1;
    private int eatTicks;

    public AutoEat() {
        super("AutoEat", "Eats food from your hotbar when you get hungry.", Category.PLAYER);
    }

    private static boolean isSafeFood(ItemStack s) {
        if (s.isEmpty() || !s.contains(DataComponentTypes.FOOD)) return false;
        return !(s.isOf(Items.ROTTEN_FLESH) || s.isOf(Items.SPIDER_EYE) || s.isOf(Items.POISONOUS_POTATO)
                || s.isOf(Items.PUFFERFISH) || s.isOf(Items.CHICKEN) || s.isOf(Items.GOLDEN_APPLE)
                || s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.SUSPICIOUS_STEW));
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) { stop(); return; }
        int food = p.getHungerManager().getFoodLevel();

        if (eating) {
            eatTicks++;
            if (food >= 20 || (eatTicks > 5 && !p.isUsingItem() && food > hunger.getInt())) stop();
            else mc.options.useKey.setPressed(true);
            return;
        }
        if (food > hunger.getInt()) return;

        for (int i = 0; i < 9; i++) {
            if (isSafeFood(p.getInventory().getStack(i))) {
                previousSlot = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(i);
                mc.options.useKey.setPressed(true);
                eating = true;
                eatTicks = 0;
                return;
            }
        }
    }

    private void stop() {
        if (!eating) return;
        mc.options.useKey.setPressed(false);
        if (mc.player != null && previousSlot >= 0) mc.player.getInventory().setSelectedSlot(previousSlot);
        previousSlot = -1;
        eating = false;
    }

    @Override
    protected void onDisable() { stop(); }
}
