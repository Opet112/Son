package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.EnderChestBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Storage ESP with memory. Some servers turn far-away chests into stone; once a container has been seen it is
 * remembered and keeps being drawn until you stand close and the server's real data shows it is gone.
 */
public class StorageEsp extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 32, 8, 64, 4));
    private final Setting.Num forgetDist = add(new Setting.Num("Forget distance", 6, 3, 16, 1));

    private final Map<String, Set<Long>> memory = new HashMap<>();
    private String lastServer = "";
    private int layer;

    public StorageEsp() {
        super("StorageEsp", "Chests/barrels/shulkers through walls, remembered even if the server hides them.", Category.RENDER);
    }

    private static boolean storage(Block b) {
        return b instanceof ChestBlock || b instanceof BarrelBlock || b instanceof EnderChestBlock || b instanceof ShulkerBoxBlock;
    }

    private Set<Long> here() {
        String dim = mc.world.getRegistryKey().getValue().toString();
        return memory.computeIfAbsent(dim, k -> new HashSet<>());
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        ServerInfo si = mc.getCurrentServerEntry();
        String server = si == null ? "single" : si.address;
        if (!server.equals(lastServer)) { memory.clear(); lastServer = server; }

        Set<Long> mem = here();
        int r = range.getInt();
        int px = (int) Math.floor(mc.player.getX()), py = (int) Math.floor(mc.player.getY()), pz = (int) Math.floor(mc.player.getZ());
        BlockPos.Mutable m = new BlockPos.Mutable();
        int dx = layer - r;
        for (int dz = -r; dz <= r; dz++) {
            for (int dy = -r; dy <= r; dy++) {
                m.set(px + dx, py + dy, pz + dz);
                if (storage(mc.world.getBlockState(m).getBlock())) mem.add(m.asLong());
            }
        }
        layer = layer >= r * 2 ? 0 : layer + 1;

        // Only trust "this is no longer a container" when the server must be sending real blocks.
        double fd = forgetDist.get();
        mem.removeIf(l -> {
            BlockPos p = BlockPos.fromLong(l);
            double ddx = p.getX() + 0.5 - mc.player.getX(), ddy = p.getY() + 0.5 - mc.player.getY(), ddz = p.getZ() + 0.5 - mc.player.getZ();
            return ddx * ddx + ddy * ddy + ddz * ddz < fd * fd && !storage(mc.world.getBlockState(p).getBlock());
        });
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        for (Long l : here()) {
            double[] s = pr.box(new Box(BlockPos.fromLong(l)));
            if (s == null) continue;
            boolean real = storage(mc.world.getBlockState(BlockPos.fromLong(l)).getBlock());
            DrawUtil.outline(ctx, (int) s[0], (int) s[1], (int) s[2], (int) s[3], real ? 0xFFFFD84A : 0xFFE8344F);
        }
    }
}
