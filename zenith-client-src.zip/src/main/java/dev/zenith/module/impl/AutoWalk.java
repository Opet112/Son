package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class AutoWalk extends Module {
    public AutoWalk() {
        super("AutoWalk", "Holds the forward key for you.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen == null) mc.options.forwardKey.setPressed(true);
    }

    @Override
    protected void onDisable() { mc.options.forwardKey.setPressed(false); }
}
