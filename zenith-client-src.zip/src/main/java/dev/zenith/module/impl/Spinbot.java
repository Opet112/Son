package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class Spinbot extends Module {
    private final Setting.Num speed = add(new Setting.Num("Speed", 30, 5, 90, 5));
    private final Setting.Num pitch = add(new Setting.Num("Pitch", 0, -90, 90, 15));

    public Spinbot() {
        super("Spinbot", "Spins your character (visible to other players).", Category.MISC);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        p.setYaw(p.getYaw() + speed.getFloat());
        p.setPitch(pitch.getFloat());
    }
}
