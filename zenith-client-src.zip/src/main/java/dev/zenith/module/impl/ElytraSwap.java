package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.util.InventoryUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/** One-shot: swaps elytra and chestplate using a hotbar item. Bind it to a key. */
public class ElytraSwap extends Module {
    public ElytraSwap() {
        super("ElytraSwap", "Swaps your chestplate and elytra (keep the other one in the hotbar).", Category.MOVEMENT);
        visible = false;
    }

    @Override
    protected void onEnable() {
        var p = mc.player;
        if (p != null && mc.interactionManager != null) {
            boolean wearingElytra = p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
            int slot = wearingElytra
                    ? InventoryUtil.findHotbar(s -> Registries.ITEM.getId(s.getItem()).getPath().endsWith("_chestplate"))
                    : InventoryUtil.findHotbar(Items.ELYTRA);
            if (slot >= 0) {
                // button = hotbar index swaps that hotbar slot with the chest armor slot (6)
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, 6, slot, SlotActionType.SWAP, p);
            }
        }
        setEnabled(false);
    }
}
