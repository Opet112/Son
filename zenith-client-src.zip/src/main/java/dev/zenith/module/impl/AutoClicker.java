package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class AutoClicker extends Module {
    private final Setting.Num cps = add(new Setting.Num("CPS", 10, 1, 20, 1));
    private final Setting.Bool randomize = add(new Setting.Bool("Randomize", true));
    private final java.util.Random rng = new java.util.Random();
    private double accumulator;

    public AutoClicker() {
        super("AutoClicker", "Holds-to-attack entities at a fixed click rate.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed()) { accumulator = 0; return; }
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        double rate = cps.get() * (randomize.get() ? 0.8 + rng.nextDouble() * 0.4 : 1.0);
        accumulator += rate / 20.0;
        while (accumulator >= 1.0) {
            accumulator -= 1.0;
            Criticals.apply();
            mc.interactionManager.attackEntity(mc.player, hit.getEntity());
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
