package dev.zenith.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.zenith.ZenithClient;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("zenith.json");
    }

    public void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : ZenithClient.modules().all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled() && m.persistEnabled());
                o.addProperty("key", m.getKey());
                JsonObject s = new JsonObject();
                for (Setting setting : m.getSettings()) s.add(setting.name, setting.toJson());
                o.add("settings", s);
                root.add(m.name, o);
            }
            JsonArray friends = new JsonArray();
            for (String f : ZenithClient.friends()) friends.add(f);
            root.add("_friends", friends);
            JsonArray xray = new JsonArray();
            for (String b : dev.zenith.module.impl.Xray.custom()) xray.add(b);
            root.add("_xray", xray);
            JsonArray wps = new JsonArray();
            for (String w : dev.zenith.module.impl.Waypoints.serialize()) wps.add(w);
            root.add("_waypoints", wps);
            Files.writeString(file(), GSON.toJson(root));
        } catch (Exception e) {
            ZenithClient.LOGGER.error("Could not save config", e);
        }
    }

    public void load() {
        Path file = file();
        if (!Files.exists(file)) return;
        try {
            JsonObject root = GSON.fromJson(Files.readString(file), JsonObject.class);
            if (root == null) return;
            if (root.has("_friends")) {
                ZenithClient.friends().clear();
                root.getAsJsonArray("_friends").forEach(e -> ZenithClient.friends().add(e.getAsString()));
            }
            if (root.has("_xray")) {
                java.util.List<String> ids = new java.util.ArrayList<>();
                root.getAsJsonArray("_xray").forEach(e -> ids.add(e.getAsString()));
                dev.zenith.module.impl.Xray.setCustom(ids);
            }
            if (root.has("_waypoints")) {
                java.util.List<String> wl = new java.util.ArrayList<>();
                root.getAsJsonArray("_waypoints").forEach(e -> wl.add(e.getAsString()));
                dev.zenith.module.impl.Waypoints.load(wl);
            }
            for (Module m : ZenithClient.modules().all()) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.setKey(o.get("key").getAsInt());
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting setting : m.getSettings()) {
                        if (!s.has(setting.name)) continue;
                        try {
                            setting.fromJson(s.get(setting.name));
                        } catch (Exception ignored) {
                            // keep the default if the stored value is malformed
                        }
                    }
                }
                if (o.has("enabled") && m.persistEnabled()) m.setEnabledSilently(o.get("enabled").getAsBoolean());
            }
        } catch (Exception e) {
            ZenithClient.LOGGER.error("Could not load config", e);
        }
    }
}
