package dev.zenith.hud;

import dev.zenith.util.ZeusTheme;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConnectScreen;
import net.minecraft.client.gui.screen.ProgressScreen;
import net.minecraft.client.gui.screen.ReconfiguringScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.world.LevelLoadingScreen;

/** Storm-and-lightning overlay for the title screen and the loading screens. */
public final class ZeusScreens {
    private ZeusScreens() {}

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> title(ctx, s));
            } else if (screen instanceof ConnectScreen || screen instanceof LevelLoadingScreen
                    || screen instanceof ReconfiguringScreen || screen instanceof ProgressScreen) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> loading(ctx, s));
            }
        });
    }

    private static void title(DrawContext ctx, Screen s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ZeusTheme.storm(ctx, s.width, s.height, 120);
        ZeusTheme.banner(ctx, mc.textRenderer, s.width, 14, "Minecraft Client");
    }

    private static void loading(DrawContext ctx, Screen s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ZeusTheme.storm(ctx, s.width, s.height, 150);
        ZeusTheme.banner(ctx, mc.textRenderer, s.width, 14, "Loading...");
    }

    /** Full-screen loading overlay used while resources load (called from the splash overlay mixin). */
    public static void splash(DrawContext ctx, int w, int h) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ZeusTheme.storm(ctx, w, h, 255);
        ZeusTheme.banner(ctx, mc.textRenderer, w, h / 2 - 14, "Loading...");
        int bw = Math.min(200, w / 2), x = w / 2 - bw / 2, y = h / 2 + 34;
        long t = System.currentTimeMillis() % 1600L;
        int seg = bw / 4, sx = x + (int) ((bw - seg) * (t / 1600.0));
        ctx.fill(x, y, x + bw, y + 3, 0xFF14204A);
        ctx.fill(sx, y, sx + seg, y + 3, ZeusTheme.GOLD);
    }
}
