package dev.zenith.mixin;

import dev.zenith.hud.ZeusScreens;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void zenith$zeus(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        try {
            ZeusScreens.splash(context, context.getScaledWindowWidth(), context.getScaledWindowHeight());
        } catch (Throwable ignored) { }
    }
}
